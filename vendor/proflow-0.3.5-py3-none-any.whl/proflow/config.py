from dataclasses import dataclass

@dataclass(frozen=True)
class Config_Shape:
    """The shape of the config data."""
    pass