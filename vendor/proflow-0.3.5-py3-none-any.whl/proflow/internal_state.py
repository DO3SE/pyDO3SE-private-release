from dataclasses import dataclass


@dataclass(frozen=True)
class Model_State_Shape:
    """The shape of the internal state."""
    pass
