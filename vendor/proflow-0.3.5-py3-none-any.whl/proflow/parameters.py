from dataclasses import dataclass

@dataclass(frozen=True)
class Parameters_Shape:
    """The shape of the parameter data."""
    pass