from dataclasses import dataclass

@dataclass(frozen=True)
class External_State_Shape:
    """The shape of the external data."""
    pass