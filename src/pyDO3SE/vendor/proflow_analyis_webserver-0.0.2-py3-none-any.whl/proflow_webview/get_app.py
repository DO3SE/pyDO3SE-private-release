import flask
from flask import send_from_directory
import os

def get_app(_name_, port=8000, datalocation='data.json'):
    app = flask.Flask(_name_, static_folder='')
    app_static_location = os.path.dirname(__file__) + '/static/'

    @app.route("/")
    def static_proxy():
        return send_from_directory(app_static_location, "force/force.html")

    @app.route("/force/force.css")
    def static_proxy_css():
        return send_from_directory(app_static_location, "force/force.css")

    @app.route("/force/force.js")
    def static_proxy_js():
        return send_from_directory(app_static_location, "force/force.js")


    @app.route("/data/<path:text>")
    def static_proxy_c(text):
        print(text)
        return app.send_static_file(datalocation)


    print(f"\nGo to http://localhost:{port} to see the example\n")
    return app
